package com.app.controllers;

import com.app.state.Variables;
import com.app.util.DBConnnection;
import models.Item;

import java.util.ArrayList;

public class ItemController extends DBConnnection {

    public void createItem(Item item){
        String query = "INSERT INTO items(item_no, item_name, item_description, price, unit)"
                + "VALUES(?,?,?,?,?)";

        try {
            connect();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,"ITM-1004");
            preparedStatement.setString(2,item.getItem_name());
            preparedStatement.setString(3, item.getItem_description());
            preparedStatement.setDouble(4,item.getPrice());
            preparedStatement.setString(5,item.getUnit());
            //preparedStatement.setString(6,"active");
            preparedStatement.executeUpdate();

            showItems();

        } catch (Exception e){
            System.out.println(e.getMessage());
        } finally {
            disconnect();
        }
    }

    public void showItem(){
        String query = "SELECT * FROM items WHERE item_no=?" ;
        try{
            connect();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, "ITM-1002");
            resultSet =  preparedStatement.executeQuery();

            while(resultSet.next()){
                int id = resultSet.getInt(1);
                String item_no = resultSet.getString(2) ;
                String item_name = resultSet.getString(3);
                String item_description = resultSet.getString(4);
                double price = resultSet.getDouble(5);
                String unit = resultSet.getString(6);
                String status = resultSet.getString(7);
                System.out.print(id);
                System.out.print(" | ");
                System.out.print(item_no);
                System.out.print(" | ");
                System.out.print(item_name);
                System.out.print(" | ");
                System.out.print(item_description);
                System.out.print(" | ");
                System.out.print(price);
                System.out.print(" | ");
                System.out.print(unit);
                System.out.print(" | ");
                System.out.print(status);
                System.out.println();
            }

        } catch (Exception e){
            e.getMessage();
        } finally {
            disconnect();
        }
    }

    public void showItems(){
        String query = "SELECT * FROM items" ;

        try{
            connect();
            statement = connection.createStatement();
            resultSet = statement.executeQuery(query);

            while(resultSet.next()){
                int id = resultSet.getInt(1);
                String item_no = resultSet.getString(2) ;
                String item_name = resultSet.getString(3);
                String item_description = resultSet.getString(4);
                double price = resultSet.getDouble(5);
                String unit = resultSet.getString(6);
                String status = resultSet.getString(7);
//                System.out.print(id);
//                System.out.print(" | ");
//                System.out.print(item_no);
//                System.out.print(" | ");
//                System.out.print(item_name);
//                System.out.print(" | ");
//                System.out.print(item_description);
//                System.out.print(" | ");
//                System.out.print(price);
//                System.out.print(" | ");
//                System.out.print(unit);
//                System.out.print(" | ");
//                System.out.print(status);
//                System.out.println();
                Item item = new Item(id,item_no,item_name,item_description,price,unit,status);
                Variables.items.add(item);
            }
        } catch (Exception e){
            System.out.println(e.getMessage());
        } finally {
            disconnect();
        }
    }

    public void updateItem(){
        String query = "UPDATE items " +
                "SET item_name = ? WHERE item_no=?";

        try{
            connect();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, "Adobo");
            preparedStatement.setString(2, "ITM-1002");
            preparedStatement.executeUpdate();
            System.out.println("Item Successfully Updated");
            showItems();
        } catch (Exception e){
            e.getMessage();
        } finally {
            disconnect();
        }
    }

    public void activateItemStatus(){
        String query = "UPDATE items " +
                "SET status = ? WHERE item_no=?";

        try{
            connect();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, "active");
            preparedStatement.setString(2, "ITM-1002");
            preparedStatement.executeUpdate();
            System.out.println("Item Successfully Updated");
            showItems();
        } catch (Exception e){
            e.getMessage();
        } finally {
            disconnect();
        }
    }

    public void deleteItem(){
        String query = "DELETE from items " +
                "WHERE item_no=?";

        try{
            connect();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, "ITM-1002");
            preparedStatement.executeUpdate();
            System.out.println("Item Successfully Deleted");
            showItems();
        } catch (Exception e){
            e.getMessage();
        } finally {
            disconnect();
        }
    }

}
