package com.app.state;

import models.Item;

import java.util.ArrayList;

public class Variables {
    public static ArrayList<Item> items;
}
