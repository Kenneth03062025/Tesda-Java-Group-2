package com.app.console;

import com.app.util.DBConnnection;
import models.Setup;


public class SetupController extends DBConnnection {

    public Setup getCurrentNumber(int id){
        String query = "SELECT identification_prefix, current_number FROM setup WHERE id=?" ;
        Setup setup = new Setup();
        try{
            connect();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1,id);
            resultSet =  preparedStatement.executeQuery();
            while(resultSet.next()){
                setup.setIdentification_prefix(resultSet.getString(1));
                setup.setCurrent_number(resultSet.getInt(2));
            }
        } catch (Exception e){
            e.getMessage();
        } finally {
            disconnect();
        }
        return setup;
    }

    public void incrementCurrentNumber(int id){
        int currentNumber = getCurrentNumber(id).getCurrent_number();
        int newNumber = currentNumber + 1;
        String query = "UPDATE setup " +
                "SET current_number = ? WHERE id=?";
        try{
            connect();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, newNumber);
            preparedStatement.setInt(2, id);
            preparedStatement.executeUpdate();
            showSetup();
        } catch (Exception e){
            e.getMessage();
        } finally {
            disconnect();
        }
    }

    public void showSetup(){
        String query = "SELECT * FROM setup" ;
        Setup setup = new Setup();
        try{
            connect();
            statement = connection.createStatement();
            resultSet =  statement.executeQuery(query);
            while(resultSet.next()){
                int id = resultSet.getInt(1);
                String identification_name = resultSet.getString(2) ;
                String identification_prefix = resultSet.getString(3);
                int starting_number = resultSet.getInt(4);
                int current_number = resultSet.getInt(5);

                System.out.print(id);
                System.out.print(" | ");
                System.out.print(identification_name);
                System.out.print(" | ");
                System.out.print(identification_prefix);
                System.out.print(" | ");
                System.out.print(starting_number);
                System.out.print(" | ");
                System.out.print(current_number);
                System.out.print(" | ");
                System.out.println();
}
        } catch (Exception e){
            e.getMessage();
        } finally {
            disconnect();
        }
    }

}
