package com.app.console;

import com.app.controllers.ItemController;
import com.app.state.Variables;
import models.Item;

import java.util.ArrayList;
import java.util.Scanner;

public class ItemConsole {

    static ItemController itc = new ItemController();

    public static void createNewItem(){
        Item item;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Name of an Item to sell.");
        String item_name = sc.nextLine();
        //Validation

        System.out.println("Enter Short Description of an Item");
        String item_description = sc.nextLine();
        //Validation

        System.out.println("Enter the Price of an Item");
        double price = sc.nextDouble();
        sc.nextLine();
        //Validation

        System.out.println("Enter the unit of an Item");
        String unit = sc.nextLine();
        //Validation

        item = new Item(item_name,item_description,price,unit);

        itc.createItem(item);

        //send to backend service
    }

    public static void displayItems(){
//        ArrayList<Item> items = new ArrayList<Item>();;
//        items.add(new Item(1,"ITM-1001","Sisig Meal","Sisig with Rice", 105.00, "Serving", "inactive"));
//        items.add(new Item(2,"ITM-1002","Sisig Meal 2","Sisig with Rice and Egg", 125.00, "Serving", "inactive"));
//        items.add(new Item(3,"ITM-1003","Sisig Meal 3","Sisig with Rice and Beacon", 125.00, "Serving", "active"));

        for ( Item i : Variables.items) {
            System.out.print(i.getId());
            System.out.print(" | ");
            System.out.print(i.getItem_no());
            System.out.print(" | ");
            System.out.print(i.getItem_name());
            System.out.print(" | ");
            System.out.print(i.getItem_description());
            System.out.print(" | ");
            System.out.print(i.getPrice());
            System.out.print(" | ");
            System.out.print(i.getUnit());
            System.out.print(" | ");
            System.out.print(i.getStatus());
            System.out.println();
        }

    }
}
