package com.app.util;

@FunctionalInterface
public interface RiskyFunction {
    void apply() throws Exception;

//    void add(int a, int b);
}
