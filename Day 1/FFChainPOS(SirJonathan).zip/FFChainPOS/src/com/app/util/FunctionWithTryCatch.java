package com.app.util;

public class FunctionWithTryCatch {

    public static void tryCatch(RiskyFunction func) {
        try {
            func.apply();
        }catch (Exception e){
            System.out.println("Exception caught: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        RiskyFunction riskyFunction = () -> {
            System.out.println("Executing risky function...");
            if (Math.random() > 0.5) {
                throw new Exception("Something went wrong!");
            } else {
                System.out.println("Risky function completed successfully.");
            }
        };

        tryCatch(riskyFunction);
    }
}
