package com.app.util;

import java.sql.*;

public abstract class DBConnnection {

    private final static String URL = "jdbc:mariadb://localhost:3306/db_ffchain_pos";
    private final static String USERNAME = "root";
    private final static String PASSWORD = "root";

    //String DRIVER = "com.mysql.jdbc.Driver";

    public Connection connection;

    public Statement statement;

    public ResultSet resultSet;

    public PreparedStatement preparedStatement;

    public void connect(){
        try{
            //Class.forName(DRIVER);
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            System.out.println("Connected Successfully");
        } catch (Exception e){
            System.out.println("Something Went Wrong " + e);
        }
    }

    public void disconnect(){
        try{
            connection.close();
        } catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

//    public static void main(String[] args) {
//        DBConnnection dbConnnection = new DBConnnection();
//        dbConnnection.connect();
//    }
}
