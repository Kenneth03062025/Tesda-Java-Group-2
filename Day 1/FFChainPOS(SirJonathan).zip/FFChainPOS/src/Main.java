import com.app.console.ItemConsole;
import com.app.console.SetupController;

public class Main {
    public static void main(String[] args) {

        ItemConsole.createNewItem();
//        ItemConsole.displayItems();

        //ItemConsole.createNewItem();
//        SetupController setup = new SetupController();
//        setup.getCurrentNumber(1);
//            setup.incrementCurrentNumber(1);
//        setup.showSetup();
    }
}